package com.example.stopwatch

import android.os.Bundle
import android.os.Handler
import android.os.SystemClock
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var isRunning: Boolean = false
    private var baseTime: Long = 0L
    private var pausedTime: Long = 0L
    private lateinit var timeTextView: TextView
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var resetButton: Button
    private val handler = Handler()

    private val runnable = object : Runnable {
        override fun run() {
            val currentTime = SystemClock.elapsedRealtime() - baseTime + pausedTime
            val hours = (currentTime / 3600000).toInt()
            val minutes = ((currentTime - hours * 3600000) / 60000).toInt()
            val seconds = ((currentTime - hours * 3600000 - minutes * 60000) / 1000).toInt()
            timeTextView.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        timeTextView = findViewById(R.id.timeTextView)
        startButton = findViewById(R.id.startButton)
        pauseButton = findViewById(R.id.pauseButton)
        resetButton = findViewById(R.id.resetButton)

        startButton.setOnClickListener(View.OnClickListener {
            if (!isRunning) {
                if (baseTime == 0L) {
                    baseTime = SystemClock.elapsedRealtime()
                } else {
                    baseTime = SystemClock.elapsedRealtime() - pausedTime
                }
                handler.postDelayed(runnable, 0)
            }

            isRunning = true
        })

        pauseButton.setOnClickListener(View.OnClickListener {
            if (isRunning) {
                handler.removeCallbacks(runnable)
                pausedTime = SystemClock.elapsedRealtime() - baseTime
            }
            isRunning = false
        })

        resetButton.setOnClickListener(View.OnClickListener {
            handler.removeCallbacks(runnable)
            baseTime = 0L
            pausedTime = 0L
            isRunning = false
            timeTextView.text = "00:00:00"
        })

        // Restore instance state if available
        savedInstanceState?.let { onRestoreInstanceState(it) }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("isRunning", isRunning)
        outState.putLong("baseTime", baseTime)
        outState.putLong("pausedTime", pausedTime)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        isRunning = savedInstanceState.getBoolean("isRunning", false)
        baseTime = savedInstanceState.getLong("baseTime", 0L)
        pausedTime = savedInstanceState.getLong("pausedTime", 0L)
        updateTimerText()
        if (isRunning) {
            handler.postDelayed(runnable, 0)
        }
    }

    private fun updateTimerText() {
        val currentTime = SystemClock.elapsedRealtime() - baseTime + pausedTime
        val hours = (currentTime / 3600000).toInt()
        val minutes = ((currentTime - hours * 3600000) / 60000).toInt()
        val seconds = ((currentTime - hours * 3600000 - minutes * 60000) / 1000).toInt()
        timeTextView.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(runnable)
    }
}


