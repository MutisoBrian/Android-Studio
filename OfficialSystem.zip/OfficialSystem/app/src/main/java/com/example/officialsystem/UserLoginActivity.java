package com.example.officialsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class UserLoginActivity extends AppCompatActivity {
    private Button button3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        button3= (Button) findViewById(R.id.button3);
        //ADMIN
        button3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openCreateUserActivity();
            }
        });

    }
    public void openCreateUserActivity() {
        Intent intent=new Intent(this,CreateUserActivity.class);
        startActivity(intent);
    }

}