package com.example.officialsystem;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button= (Button) findViewById(R.id.button);
        Button button2 = (Button) findViewById(R.id.button2);
        //ADMIN
        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openAdminLoginActivity();
            }
        });


        //USER
        button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                openUserLoginActivity();
            }
        });
    }

    private void openAdminLoginActivity() {
        Intent intent2 = new Intent(this, AdminLoginActivity.class);
        startActivity(intent2);
    }

    public void openUserLoginActivity() {
        Intent intent=new Intent(this,UserLoginActivity.class);
        startActivity(intent);
    }

}